<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Formulario NBA</title>
  </head>
  <body>
  <form class="" action="filtrado.php" method="post">
<?php
include "nbaDB.php";
$nba=new NBAdb();
?>
<br>Equipo Local<br>
<select name="local">
<?php

$local=$nba->local();
while ($fila=$local->fetch_assoc()){
echo "<option value='".$fila["equipo_local"]."'>".$fila["equipo_local"]."</option>";
}
?>
</select>
<br>
<br>Equipo Visitante<br>
<select name="visitante">
<?php


$visitante=$nba->visitante();
while ($fila=$visitante->fetch_assoc()){
echo "<option value='".$fila["equipo_visitante"]."'>".$fila["equipo_visitante"]."</option>";
}
?>
</select>
<br>
<br>Temporada<br>
<select name="temporada">
<?php


$temporada=$nba->temporada();
while ($fila=$temporada->fetch_assoc()){
echo "<option value='".$fila["temporada"]."'>".$fila["temporada"]."</option>";

}


 ?>
</select>
<br><br>
    <button>Enviar</button>
  </body>
</html>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Filtrado</title>
  </head>
  <body>
<?php
//Conexión a la DB
include "nbaDB.php";
//Comprobación de POST

if(isset( $_POST["local"]) && !empty($_POST["local"])) {
$nba=new NBAdb();
$resultado=$nba->MostrarEquipo($_POST["local"],$_POST["visitante"],$_POST["temporada"]);
while ($fila=$resultado->fetch_assoc()) {
echo "Nombre de equipo Local es: " . $fila["equipo_local"] . "<br>";
echo "Puntos de equipo Local es: " . $fila["puntos_local"] . "<br>";
echo "Nombre de equipo Visitante es: " . $fila["equipo_visitante"] . "<br>";
echo "Puntos de equipo Visitante es: " . $fila["puntos_visitante"] . "<br>";
echo "La temporada es: " . $fila["temporada"] . "<br><br>";
}
}else{
?>
<a href="index.html">No envia nada</a>
<?php
}

?>
      </form>
  </body>
</html>
